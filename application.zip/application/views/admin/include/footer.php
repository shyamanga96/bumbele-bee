<footer class="main-footer">
	<div class="footer-left">
		Copyright &copy; 2020 <div class="bullet"></div> Blue Ember LLC, All Rights Reserved.
	</div>
	<div class="footer-right">
	</div>
</footer>