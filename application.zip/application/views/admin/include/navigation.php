<!-- General CSS Files -->
<link rel="stylesheet" href="<?php echo base_url(); ?>application_res/admin/css/app.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>application_res/admin/bundles/jqvmap/dist/jqvmap.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>application_res/admin/bundles/weather-icon/css/weather-icons.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>application_res/admin/bundles/weather-icon/css/weather-icons-wind.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>application_res/admin/bundles/summernote/summernote-bs4.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>application_res/admin/bundles/codemirror/lib/codemirror.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>application_res/admin/bundles/codemirror/theme/duotone-dark.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>application_res/admin/bundles/jquery-selectric/selectric.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>application_res/admin/bundles/izitoast/css/iziToast.min.css">
<!-- Template CSS -->
<link rel="stylesheet" href="<?php echo base_url(); ?>application_res/admin/css/style.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>application_res/admin/css/components.css">
<!-- Custom style CSS -->
<link rel="stylesheet" href="<?php echo base_url(); ?>application_res/admin/css/custom.css">

<link rel="stylesheet" href="<?php echo base_url(); ?>application_res/admin/bundles/datatables/datatables.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>application_res/admin/bundles/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css">

<link href="https://cdnjs.cloudflare.com/ajax/libs/jquery-toast-plugin/1.3.1/jquery.toast.min.css" rel="stylesheet" type="text/css">
<link href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.4/sweetalert2.css" rel="stylesheet" type="text/css">

<link rel='shortcut icon' type='image/x-icon' href='<?php echo base_url(); ?>application_res/admin/img/favicon.png' />

