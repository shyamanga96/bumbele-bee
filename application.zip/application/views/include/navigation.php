    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url(); ?>application_res/images/favicon.png">

    <link rel="stylesheet" href="<?php echo base_url(); ?>application_res/css/vendor/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>application_res/css/vendor/font-awesome.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>application_res/css/vendor/flaticon/flaticon.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>application_res/css/vendor/slick.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>application_res/css/vendor/slick-theme.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>application_res/css/vendor/jquery-ui.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>application_res/css/vendor/sal.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>application_res/css/vendor/magnific-popup.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>application_res/css/vendor/base.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>application_res/css/style.min.css">